public class Quadrado extends Forma //a classe é um projeto de objeto! quando realizamos um 'new', é o projeto finalizado!
{
   public void CalcularArea()
    {
      System.out.println("Calculo específico de: Quadrado");
    }
}