//tudo que eu fizer aqui é uma subescrita referente a amoeba! SUBESCRITAAA!! 
class Forma
{ 
  String cor;
  public void MostrarCor()
    {
      System.out.println("A cor é: "+cor);
    }
    public void CalcularArea()
  {
  }
}