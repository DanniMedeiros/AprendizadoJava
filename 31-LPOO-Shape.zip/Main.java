class Main 
{
  public static void main(String[] args) 
  {

    Circulo circ = new Circulo();
    circ.cor = "Cinza";
    circ.CalcularArea();
    circ.MostrarCor();

    Quadrado quad = new Quadrado();
    quad.cor = "Azul";
    quad.CalcularArea();
    quad.MostrarCor();

    Triangulo tria = new Triangulo();
    tria.cor = "Preto";
    tria.CalcularArea();
    tria.MostrarCor();
    
    Forma[] lista = new Forma[3];
    lista[0] = circ;
    lista[1] = quad;
    lista[2] = tria;

    lista[0].CalcularArea();
    lista[0].MostrarCor();
    lista[1].CalcularArea();
    lista[1].MostrarCor();
    lista[2].CalcularArea();
    lista[2].MostrarCor();
  }
}