public class Guerreiro
  {
    int poderAtaque;
    public void Atacar()
    {
      System.out.println("Ataque do guerreiro realizado no valor de: "+poderAtaque);
    }
  }