public class GuerreiroGelo extends GuerreiroAgua
  {
    int poderGelo; //atributo
    public void AtacarGelo() //método
    {
      System.out.println("Ataque de gelo realizado no valor de: "+(super.poderAgua*this.poderGelo));
    }
  }