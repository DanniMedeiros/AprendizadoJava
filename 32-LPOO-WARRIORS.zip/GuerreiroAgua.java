public class GuerreiroAgua extends Guerreiro
  {
    int poderAgua;
    public void AtacarAgua()
    {
      System.out.println("Ataque de agua realizado no valor de: "+poderAgua);
    }
  }