class Main 
{
  public static void main(String[] args) 
  {
    Guerreiro g1 = new Guerreiro();
    g1.poderAtaque = 30;
    g1.Atacar();
    GuerreiroAgua ga1 = new GuerreiroAgua();
    ga1.poderAgua = 40;
    ga1.AtacarAgua();
    GuerreiroFogo gf1 = new GuerreiroFogo();
    gf1.poderFogo = 30;
    gf1.AtacarFogo();
    GuerreiroGelo gg1 = new GuerreiroGelo();
    gg1.poderGelo = 30;
    gg1.poderAgua = 10;
    gg1.AtacarGelo();    

    /*Guerreiro[] lista = new Guerreiro[3];
    lista[0] = ga1;
    lista[1] = gf1;
    lista[2] = gg1;
      ***aqui vai acontecer um erro pois estamos chamando apenas a classe "Guerreiro"***.
    lista[0].AtacarAgua();
    lista[1].AtacarFogo();
    lista[2].AtacarGelo();*/
  }
}