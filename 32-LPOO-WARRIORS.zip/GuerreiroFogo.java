public class GuerreiroFogo extends Guerreiro
  {
    int poderFogo;
    public void AtacarFogo()
    {
      System.out.println("Ataque de fogo realizado no valor de: "+poderFogo);
    }
  }