class AnimaisTerrestres extends Animal
  {
    public void executarComportamento()
    {
      System.out.println("o Animal "+nome+" da raça "+raca+" está andando");
    }
    public void Andar(){}
  }