class AnimaisAquaticos extends Animal
  {
    public void executarComportamento()
    {
      System.out.println("o Animal "+nome+" da raça "+raca+" está nadando");
    }
    public void Nadar(){}
  }