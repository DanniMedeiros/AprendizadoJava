class Zoologico
  {
    String nome, raca;
    int peso;
    public static void main(String[] args) 
  {
    AnimaisAquaticos an = new AnimaisAquaticos();
    an.nome= "Jorge";
    an.raca= "tartaruga";
    an.peso= 180;
    an.executarComportamento();
    AnimaisAquaticos an1 = new AnimaisAquaticos();
    an1.nome= "CLeiton";
    an1.raca= "arraia";
    an1.peso= 50;
    an1.executarComportamento();
    AnimaisAquaticos an2 = new AnimaisAquaticos();
    an2.nome= "Batata";
    an2.raca= "cavalo marinho";
    an2.peso= 50;
    an2.executarComportamento();
    AnimaisTerrestres at = new AnimaisTerrestres();
    at.nome= "Givanildo";
    at.raca= "louva deus";
    at.peso= 180;
    at.executarComportamento();
    AnimaisTerrestres at1 = new AnimaisTerrestres();
    at1.nome= "Joao";
    at1.raca= "helefante";
    at1.peso= 50;
    at1.executarComportamento();
    AnimaisTerrestres at2 = new AnimaisTerrestres();
    at2.nome= "Henrique";
    at2.raca= "coelho";
    at2.peso= 50;
    at2.executarComportamento();   
  }
}
  