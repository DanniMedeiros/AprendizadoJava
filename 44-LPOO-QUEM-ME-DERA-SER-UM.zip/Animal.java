class Animal extends Zoologico
  {
    String nome, raca;
    int peso;
    public void executarComportamento(){}
  }