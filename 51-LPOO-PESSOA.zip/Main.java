class Main {
  public static void main(String[] args) 
  {
    Pessoa p = new Pessoa();
    p.setNome("Jubileu");
    p.setSexo("Feminino");
    p.setIdade(15);
    p.setAltura(1.60f);
    p.setPeso(60.4f);

    System.out.println("Nome: "+p.getNome()+". Sexo: "+p.getSexo()+". Idade: "+p.getIdade()+". Altura: "+p.getAltura()+". Peso: "+p.getPeso());
  }
}