public class Pessoa
  {
    private String nome, sexo;
    private int idade;
    private float altura, peso;

    public void setNome(String n)
    {
      this.nome = n;
    }
    public String getNome()
    {
      return this.nome;
    }
    public void setSexo(String s)
    {
      this.sexo = s;
    }
    public String getSexo()
    {
      return this.sexo;
    }
    public void setIdade(int i)
    {
      this.idade = i;
    }
    public int getIdade()
    {
      return this.idade;
    }
    public void setAltura(float a)
    {
      this.altura = a;
    }
    public float getAltura()
    {
      return this.altura;
    }
    public void setPeso(float p)
    {
      this.peso = p;
    }
    public float getPeso()
    {
      return this.peso;
    }
  
  }