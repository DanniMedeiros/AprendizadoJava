public class Pessoa
  {
  String Nome;
  int Peso, Idade;
  float Altura;
 
  
  public void CalculoIMC()
    {
      float imc = (float)Peso/(Altura*Altura); 
      System.out.println("O IMC da pessoa com nome:"+Nome+". E seu IMC é: "+imc);
    }
  }