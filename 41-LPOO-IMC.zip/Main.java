class Main 
{
  public static void main(String[] args) 
  {
    Pessoa p = new Pessoa();
    p.Nome = "Joao";
    p.Altura = 1.80f;
    p.Idade = 27;
    p.Peso = 90;
    p.CalculoIMC();
    Pessoa p1 = new Pessoa();
    p1.Nome = "Maria";
    p1.Altura = 1.60f;
    p1.Idade = 40;
    p1.Peso = 70;
    p1.CalculoIMC();
    Pessoa p2 = new Pessoa();
    p2.Nome = "Sabrino";
    p2.Altura = 1.90f;
    p2.Idade = 30;
    p2.Peso = 100;
    p2.CalculoIMC();
  }
}