public class Pessoa{
  String nome;
  int idade;
  public void RealizarAP()
  {
    System.out.println(" Olá, sou "+nome+" tenho "+idade+" anos"); //PROFESSOR INCRÍVEL
  }
}