import java.util.Scanner;
class Main
  {
  public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    System.out.print("Digite o nome: ");
    String Nome = entrada.nextLine();
    System.out.print("Digite sua idade: ");
    int Idade = entrada.nextInt();
     //System.out.print("Você se chama "+Nome+". E sua idade é "+Idade); 
    Pessoa P1 = new Pessoa(); //instancia
    P1.idade = Idade;
    P1.nome = Nome;
    P1.RealizarAP();
    Pessoa P2 = new Pessoa(); //instancia
    P2.idade = 54;
    P2.nome = "Gertrudes";
    P2.RealizarAP();
  }
}
