public class Cao
  {
  String Nome, Pet, somLatido;

    public void Latir()
    {
      System.out.println(Nome+" está latindo: "+somLatido);
    }
  }